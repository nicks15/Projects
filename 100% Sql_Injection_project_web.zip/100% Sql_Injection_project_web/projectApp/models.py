from django.db import models
from django.db import models
from django.contrib.auth.models import User

class UserProfile(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()
    mobile = models.CharField(max_length=20)
    address = models.TextField()
    credit_no = models.CharField(max_length=10)
    credit_type = models.CharField(max_length=100)
    cvv = models.CharField(max_length=10)
    Expiredate = models.DateField()
    zipcode = models.CharField(max_length=10)
    