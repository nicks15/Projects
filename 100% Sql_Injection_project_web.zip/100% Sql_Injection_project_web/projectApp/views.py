from django.db import IntegrityError

from django.shortcuts import  render, redirect
from .forms import NewUserForm
from django.contrib.auth import login
from django.contrib import messages
from .forms import NewUserForm
from django.contrib.auth import login, logout, authenticate #add this
from django.contrib import messages
from django.contrib.auth.forms import AuthenticationForm #add this
#from projectApp.models import Register

import os
import time
import random

import requests

import requests
from django.shortcuts import render, HttpResponse
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
#from .forms import UserRegisterForm
from django.contrib.auth.forms import UserCreationForm
import numpy as np
import joblib
from django.contrib.auth.models import User
import os
from joblib import dump , load

import pickle



# Create your views here.
def index(request):
        return render(request, 'index.html')
        
def input(request):
    return render(request, 'input.html')

        
def fakenew(request):
    return render(request, 'fakenew.html')


def result(request):
        
        link = request.GET['a']
        #a = request.GET['fname']
        print(link)
        
        #page = requests.get(link)
        #print(page)

        predictor = load("D://web project 2022-2023//Sql_Injection_project_web//projectApp//SVM_MODEL.joblib")
        #Given_text = entry.get()
        #Given_text = "the 'roseanne' revival catches up to our thorny po..."
        vec = open('D://web project 2022-2023//Sql_Injection_project_web//projectApp//vectorizer.pickle','rb')
        tf_vect = pickle.load(vec)
        X_test_tf = tf_vect.transform([link])
        y_predict = predictor.predict(X_test_tf)
        print(y_predict[0])
        if y_predict[0]==0:
            print("SQL injection detected")
            value = 'SQL injection detected'
            
        
        else:
            print("SQL injection  not detected")
            value = 'SQL injection  not detected'

    
        return render(request,'result.html',  {
                      'ans': value,
                      'title': 'SQL Injection Detected using Machine Learning',
                      'active': 'btn btn-success peach-gradient text-white',
                      'result': True,
                      
                  })
    
from .forms import UserProfileForm
def userprofile(request):
    if request.method == 'POST':
        form = UserProfileForm(request.POST)
        if form.is_valid():
            account = form.save(commit=False)
            account.user = request.user
            account.save()
           # messages.success(request, "Registration successful." )
            return redirect('input')  # Redirect to your dashboard or home page
    else:
        form = UserProfileForm()
    return render(request, 'credit_card.html', {'form': form})
    

def register(request):
	if request.method == "POST":
		form = NewUserForm(request.POST)
		if form.is_valid():
			user = form.save()
			login(request, user)
			messages.success(request, "Registration successful." )
			return redirect('login1')
		messages.error(request, "Unsuccessful registration. Invalid information.")
	form = NewUserForm()
	return render (request=request, template_name="register.html", context={"register_form":form})

def login1(request):
	if request.method == "POST":
		form = AuthenticationForm(request, data=request.POST)
		if form.is_valid():
			username = form.cleaned_data.get('username')
			password = form.cleaned_data.get('password')
			user = authenticate(username=username, password=password)
			if user is not None:
				login(request, user)
				messages.info(request, f"You are now logged in as {username}.")
				return redirect('input')
			else:
				messages.error(request,"Invalid username or password.")
		else:
			messages.error(request,"Invalid username or password.")
	form = AuthenticationForm()
	return render(request=request, template_name="login.html", context={"login_form":form})

def logout_request(request):
	logout(request)
	messages.info(request, "You have successfully logged out.") 
	return redirect('login1')