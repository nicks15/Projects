from django.contrib import admin
#from projectApp.models import Register
from django.contrib.auth.admin import UserAdmin


